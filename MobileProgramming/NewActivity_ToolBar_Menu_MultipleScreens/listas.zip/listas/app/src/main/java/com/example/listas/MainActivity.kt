package com.example.listas

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val len = arrayOf("java","c","c++","javascript","python")

        val lista = findViewById<ListView>(R.id.lista)
        val spinn = findViewById<Spinner>(R.id.spinner1)

        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, len)
        lista.adapter = arrayAdapter

        lista.setOnItemClickListener { _, _, position, _ ->
            val langselect = len[position]
            Toast.makeText(this, "seleccionaste: $langselect", Toast.LENGTH_LONG).show()
        }

        val semana = resources.getStringArray(R.array.semana)
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, semana)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinn.adapter = spinnerAdapter

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}